# Cloud server (MQTT + ASR)

Receives the device's keyword events and audio, runs ASR (MOCK_ASR by default), and publishes a command back.

## Run

```bash
cd cloud_server
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env        # optional; edit if you need non-defaults
python server.py
```

Expected log when the Wokwi device detects the keyword:

```
[STATUS] device device01 is ONLINE (retained)
[EVENT] KEYWORD_DETECTED - device is capturing the command
[AUDIO] SIMULATED_AUDIO_SUMMARY request=device01-0001 samples=16384 (1024 ms) rms=616 peak=1299 kws=MOCK_KWS p=1 simulated=True
[ASR] MOCK_ASR transcript: 'turn on the light' -> command TURN_ON
[COMMAND] -> sih/device01/command {"request_id":"device01-0001","command":"TURN_ON",...}
```

## Configuration (environment variables or `.env`)

| Variable | Default | Notes |
|---|---|---|
| `MQTT_BROKER` | `test.mosquitto.org` | Public, unauthenticated test broker. Must match the device. |
| `MQTT_PORT` | `1883` | Use `8883` with `MQTT_TLS=1` for TLS brokers. |
| `MQTT_USERNAME` / `MQTT_PASSWORD` | empty | Empty means no authentication. |
| `MQTT_TLS` | `0` | `1` = TLS using the system CA store. |
| `MQTT_CLIENT_ID` | random `sih-cloud-device01-xxxxxx` | |
| `DEVICE_ID` | `device01` | Topics are `sih/<DEVICE_ID>/...`. Must match the firmware. |
| `ASR_MODE` | `mock` | `real` selects the REAL_ASR placeholder if the engine module is importable. |
| `ASR_ENGINE_MODULE` | `whisper` | The module probed for `ASR_MODE=real`. |
| `LOG_LEVEL` | `INFO` | `DEBUG` shows every PCM chunk. |

No credentials are stored in code. `.env` is git-ignored.

## ASR (`asr.py`)

The interface is `transcribe(audio_data, sample_rate=16000) -> ASRResult`.

`MOCK_ASR` returns deterministic phrases chosen from the request sequence number: seq 1 is "turn on the light", seq 2 is "turn off the light", seq 3 is "what is the status", and then the cycle repeats.

`REAL_ASR` is a placeholder. It probes for the engine module and then raises `NotImplementedError` at the marked `INSERT REAL ASR HERE` spot, and the service falls back to MOCK_ASR. It also falls back when the input is a simulated summary rather than PCM. Either way, the server never stops.

To plug in a real engine (Whisper, a whisper.cpp binding, Vosk, …):

1. Install the engine.
2. Load the model in `RealASR.__init__`.
3. Implement `RealASR.transcribe()` following that engine's documentation.
4. Run with `ASR_MODE=real ASR_ENGINE_MODULE=<module>`.

Real ASR only makes sense once the device streams real PCM (INMP441).

## Audio input formats accepted on `sih/<device>/audio`

1. **JSON summary** (`SIMULATED_AUDIO_SUMMARY` / `AUDIO_SUMMARY`): the Wokwi build. The server replies immediately.
2. **Binary PCM chunks** (real device): a 12-byte little-endian header `<u32 seq><u32 chunk_index><u32 sample_count>` followed by `sample_count` int16 LE samples. Send `{"type":"AUDIO_END","request_id":"...","seq":N}` afterwards, and the server reassembles the chunks in order, transcribes, and replies. The limit is 10 s per request.

Malformed messages are logged and ignored.
