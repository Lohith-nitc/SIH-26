// Copy to secrets.h for LOCAL builds (Arduino IDE / PlatformIO) and add
// secrets.h to .gitignore. Every value here is optional — anything you leave
// out falls back to the defaults in sketch.ino.
// Do NOT add secrets.h to a public or shared Wokwi project.
#pragma once

// #define WIFI_SSID      "your-ssid"
// #define WIFI_PASSWORD  "your-password"
// #define WIFI_CHANNEL   0            // 0 = any channel (real hardware)

// #define MQTT_BROKER    "your-broker.example"
// #define MQTT_PORT      1883
// #define MQTT_USERNAME  "device01"
// #define MQTT_PASSWORD  "..."
// #define MQTT_CLIENT_ID "sih-device01"

// #define DEVICE_ID      "device01"   // changes all topics: sih/<DEVICE_ID>/...
// #define USE_INMP441    1            // real microphone (after implementing it)
// #define FORCE_MOCK_KWS 1            // ignore an installed Edge Impulse library
