# Test client that sends exactly what the firmware sends, then the future binary-PCM protocol.
import json, struct, time, threading, paho.mqtt.client as mqtt
got = []; ev = threading.Event()
def on_msg(c, u, m): got.append(json.loads(m.payload)); ev.set()
c = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id="fake-device")
c.will_set("sih/device01/status", "OFFLINE", qos=1, retain=True)
c.on_message = on_msg; c.connect(__import__("os").getenv("MQTT_BROKER","localhost"), 1883); c.subscribe("sih/device01/command", 1); c.loop_start(); time.sleep(0.3)
c.publish("sih/device01/status", "ONLINE", qos=1, retain=True)
for seq in (1, 2, 3):
    ev.clear()
    c.publish("sih/device01/event", "KEYWORD_DETECTED")
    summary = {"type":"SIMULATED_AUDIO_SUMMARY","simulated":True,"device_id":"device01","request_id":f"device01-{seq:04d}","seq":seq,
               "sample_rate":16000,"channels":1,"format":"pcm_s16le","samples":16384,"duration_ms":1024,"rms":616,"peak":1299,
               "kws_backend":"MOCK_KWS","kws_label":"hey_comet","kws_probability":1,"audio_source":"SimulatedAudioSource","uptime_ms":9364}
    t0 = time.time(); c.publish("sih/device01/audio", json.dumps(summary)); assert ev.wait(3), "no command"
    print(f"DEVICE got ({(time.time()-t0)*1000:.0f} ms):", got[-1])
# future real-device path: binary chunks + AUDIO_END
ev.clear(); c.publish("sih/device01/event", "KEYWORD_DETECTED")
for i in range(32):
    c.publish("sih/device01/audio", struct.pack("<III", 123, i, 512) + b"\x10\x00" * 512)
c.publish("sih/device01/audio", json.dumps({"type":"AUDIO_END","request_id":"device01-0123","seq":123}))
assert ev.wait(3); print("DEVICE got (PCM path):", got[-1])
c.publish("sih/device01/audio", b"{bad json"); c.publish("sih/device01/audio", b"\x01\x02")
time.sleep(0.5); c.loop_stop(); c.disconnect()
