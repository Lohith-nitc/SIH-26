# Tests

* `host_sim/run.sh [seconds]`: runs the real `wokwi/sketch.ino` on Linux (g++) with stub Arduino/WiFi/PubSubClient headers and a fake cloud, in simulated time. The scenario covers the timeline keywords and distractors, a button press at 15 s, and a Wi-Fi drop from 45–48 s. It tests logic and determinism; it does not replace a real ESP32 build.
* `fake_device.py`: an MQTT client that sends exactly what the firmware sends (plus the future binary-PCM protocol) to exercise `cloud_server/server.py`. Run it with a local broker, e.g. `mosquitto -p 1883` and `MQTT_BROKER=localhost python server.py`.
