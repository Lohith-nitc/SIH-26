#!/usr/bin/env bash
# Runs the REAL sketch.ino on Linux against stub Arduino/WiFi/PubSubClient headers
# and an in-process fake cloud, in simulated time. Checks logic only; it does not
# replace compiling with the ESP32 toolchain (Wokwi / Arduino IDE).
set -euo pipefail
cd "$(dirname "$0")"
[ -d ArduinoJson ] || git clone -q --depth 1 https://github.com/bblanchon/ArduinoJson.git
g++ -std=gnu++17 -O1 -Wall -Wno-unused-parameter -Wno-misleading-indentation \
    -Istubs -IArduinoJson/src -I../../wokwi main_test.cpp -o sim
./sim "${1:-75}"
