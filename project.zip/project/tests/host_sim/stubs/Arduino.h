// HOST-TEST STUB — minimal Arduino API so sketch.ino can run on Linux.
#pragma once
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <cstdarg>
#include <string>
typedef uint8_t byte;
typedef bool boolean;
#define HIGH 1
#define LOW 0
#define OUTPUT 1
#define INPUT_PULLUP 2
extern uint64_t g_us;
inline unsigned long millis() { return (unsigned long)(g_us / 1000); }
inline unsigned long micros() { return (uint32_t)g_us; }
inline void delay(unsigned long ms) { g_us += ms * 1000ULL; }
void pinMode(int, int);
void digitalWrite(int, int);
int digitalRead(int);
struct SerialStub {
  void begin(long) {}
  void println(const char* s = "") { std::printf("[%9.3f] %s\n", g_us / 1e6, s); }
  int printf(const char* fmt, ...) {
    char b[1024]; va_list ap; va_start(ap, fmt); int n = std::vsnprintf(b, sizeof b, fmt, ap); va_end(ap);
    std::printf("[%9.3f] %s", g_us / 1e6, b); return n;
  }
};
extern SerialStub Serial;
struct EspStub { uint64_t getEfuseMac() { return 0x24A1B2C3D4E5ULL; } };
extern EspStub ESP;
