// HOST-TEST STUB — fake Wi-Fi: connects 1.5 s after begin(); can be dropped.
#pragma once
#include "Arduino.h"
#define WL_CONNECTED 3
#define WL_DISCONNECTED 6
#define WIFI_STA 1
struct IPAddress { std::string toString() const { return "10.13.37.2"; } };
struct WiFiClass {
  bool up = false; uint64_t connectAt = 0; uint64_t dropStart = 0, dropEnd = 0;
  void mode(int) {}
  void begin(const char*, const char*, int) {
    uint64_t base = (g_us >= dropStart && g_us < dropEnd) ? dropEnd : g_us; connectAt = base + 1500000ULL; }
  int status() {
    if (g_us >= dropStart && g_us < dropEnd) { up = false; connectAt = connectAt > dropEnd ? connectAt : 0; }
    if (!up && connectAt && g_us >= connectAt) up = true;
    return up ? WL_CONNECTED : WL_DISCONNECTED; }
  void disconnect() { up = false; connectAt = 0; }
  IPAddress localIP() { return {}; }
  int8_t RSSI() { return -58; }
};
extern WiFiClass WiFi;
struct WiFiClient {};
