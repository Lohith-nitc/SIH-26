// HOST-TEST STUB — fake PubSubClient that talks to an in-process fake cloud.
#pragma once
#include "WiFi.h"
typedef void (*MqttCb)(char*, uint8_t*, unsigned int);
void fakeCloudOnPublish(const char* topic, const uint8_t* p, unsigned int n);
bool fakeCloudPoll(std::string& topic, std::string& payload);
class PubSubClient {
 public:
  explicit PubSubClient(WiFiClient&) {}
  PubSubClient& setServer(const char*, uint16_t) { return *this; }
  PubSubClient& setCallback(MqttCb cb) { cb_ = cb; return *this; }
  bool setBufferSize(uint16_t n) { buf_ = n; return true; }
  PubSubClient& setSocketTimeout(uint16_t) { return *this; }
  PubSubClient& setKeepAlive(uint16_t) { return *this; }
  bool connect(const char*, const char*, const char*, const char*, uint8_t, bool, const char*) {
    if (WiFi.status() != WL_CONNECTED) { st_ = -2; return false; }
    g_us += 150000; up_ = true; st_ = 0; return true; }
  bool connected() { if (up_ && WiFi.status() != WL_CONNECTED) { up_ = false; st_ = -3; } return up_; }
  int state() { return st_; }
  void disconnect() { up_ = false; st_ = -1; }
  bool subscribe(const char*, uint8_t) { return up_; }
  bool publish(const char* t, const char* p, bool r = false) { return publish(t, (const uint8_t*)p, strlen(p), r); }
  bool publish(const char* t, const uint8_t* p, unsigned int n, bool = false) {
    if (!up_ || n + strlen(t) + 8 > buf_) return false; fakeCloudOnPublish(t, p, n); return true; }
  void loop() { std::string t, p; while (fakeCloudPoll(t, p)) cb_((char*)t.c_str(), (uint8_t*)p.data(), p.size()); }
 private:
  MqttCb cb_ = nullptr; uint16_t buf_ = 256; bool up_ = false; int st_ = -1;
};
