// Host harness: runs setup()/loop() in simulated time with a fake cloud.
#include <Arduino.h>
#include <WiFi.h>
#include <vector>
#include <ArduinoJson.h>
uint64_t g_us = 0; SerialStub Serial; EspStub ESP; WiFiClass WiFi;
static int pins[64]; static int lightChanges = 0, lastLight = 0;
void pinMode(int p, int m) { if (m == INPUT_PULLUP) pins[p] = 1; }
void digitalWrite(int p, int v) { pins[p] = v; if (p == 7 && v != lastLight) { lastLight = v; lightChanges++; } }
static uint64_t btnDown = 15000000, btnUp = 15100000;
int digitalRead(int p) { if (p == 14) return (g_us >= btnDown && g_us < btnUp) ? 0 : 1; return pins[p]; }
struct Msg { uint64_t at; std::string t, p; };
static std::vector<Msg> q; static int audioMsgs = 0, events = 0;
static const char* CMDS[][2] = {{"TURN_ON","turn on the light"},{"TURN_OFF","turn off the light"},{"STATUS","what is the status"}};
void fakeCloudOnPublish(const char* t, const uint8_t* p, unsigned int n) {
  std::string topic(t), payload((const char*)p, n);
  if (topic.find("/event") != std::string::npos) events++;
  if (topic.find("/audio") == std::string::npos) return;
  JsonDocument d; if (deserializeJson(d, payload)) { std::printf("!! bad audio json\n"); return; }
  std::string rid = d["request_id"] | "";
  int k = audioMsgs++ % 3;
  if (audioMsgs == 1) {  // exercise robustness paths once
    q.push_back({g_us + 100000, "sih/device01/command", "{\"request_id\":\"device01-9999\",\"command\":\"TURN_OFF\",\"text\":\"x\"}"});
    q.push_back({g_us + 150000, "sih/device01/command", "{not json"});
  }
  q.push_back({g_us + 400000, "sih/device01/command",
               std::string("{\"request_id\":\"") + rid + "\",\"command\":\"" + CMDS[k][0] + "\",\"text\":\"" + CMDS[k][1] + "\"}"});
}
bool fakeCloudPoll(std::string& t, std::string& p) {
  for (size_t i = 0; i < q.size(); ++i) if (g_us >= q[i].at) { t = q[i].t; p = q[i].p; q.erase(q.begin() + i); return true; }
  return false;
}
#include "sketch.ino"
int main(int argc, char** argv) {
  double seconds = argc > 1 ? atof(argv[1]) : 60;
  WiFi.dropStart = 45000000; WiFi.dropEnd = 48000000;   // simulate AP loss 45–48 s
  setup();
  while (g_us < (uint64_t)(seconds * 1e6)) { loop(); g_us += 1000; }
  std::printf("\n== SUMMARY: events=%d audio_packets=%d light_changes=%d final_state=%s\n",
              events, audioMsgs, lightChanges, STATE_NAMES[state]);
}
